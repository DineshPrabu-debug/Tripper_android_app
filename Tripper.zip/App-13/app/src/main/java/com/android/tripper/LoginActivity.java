package com.android.tripper;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;

public class LoginActivity extends AppCompatActivity {



//    private GoogleSignInClient googleSignInClient;
//    private SignInButton googleSignInButton;
//
//    @Override
//    protected void onCreate( Bundle savedInstanceState) {
//
//        super.onCreate(savedInstanceState);
//        googleSignInButton  = findViewById(R.id.sign_in_button);
//        setContentView(R.layout.sign_in_button);
//
//        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
////      updateUI(account);
//        //Configure sign-in to request the user's ID, email address, and basic
//        // profile. ID and basic profile are included in DEFAULT_SIGN_IN.
////
////        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
////                .requestIdToken()
////                .requestEmail()
////                .build();
//
//        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
//                .requestEmail()
//                .build();
//
//        // Build a GoogleSignInClient with the options specified by gso.
//
//        googleSignInClient  = GoogleSignIn.getClient(this, gso);
//
//        googleSignInButton.setSize(SignInButton.SIZE_WIDE);
//
//       googleSignInButton.setOnClickListener(new View.OnClickListener() {
//           @Override
//           public void onClick(View view) {
//
//               Intent signInClient = googleSignInClient.getSignInIntent();
//               startActivityForResult(signInClient,101);
//           }
//       });

        }


